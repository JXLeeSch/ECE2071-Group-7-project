import serial
import struct
import subprocess
import time
import matplotlib.pyplot as plt
import csv
import os

SAMPLE_RATE = 22000
COM_PORT = "COM5"
BAUD_RATE = 921600
TEAM_ID = "Team07"

IDLE_TIMEOUT = 1
 
def connect_serial():
    ser = serial.Serial(port=COM_PORT,baudrate=BAUD_RATE,bytesize=8,parity="N",stopbits=1,timeout=0.1)
    print(ser.name)
    return ser

def generate_wav():
    compile_result = subprocess.run(["gcc", "adc_to_wav.c", "-o", "adc_to_wav"],capture_output=True,text=True)

    if compile_result.returncode != 0:
        print("Compilation failed:")
        print(compile_result.stderr)
        return
    else:
        print("Compilation successful.")

    output_filename = f"{TEAM_ID}_{SAMPLE_RATE}Hz_output.wav"
    run_result = subprocess.run(
        ["adc_to_wav.exe", "raw_ADC_values.data", output_filename, str(SAMPLE_RATE)],
        capture_output=True, text=True
    )#use ["./adc_to_wav"] for linux, ["adc_to_wav.exe"] for windows

    if run_result.returncode != 0:
        print("C program failed:")
        print(run_result.stderr)
    else:
        print(f"WAV file generated: {output_filename}")

def save_files(ser):
    raw_bytes = bytearray()
    binary_file = open("raw_ADC_values.data", "wb")
    last_data_time = time.time()
    start_time = None

    while True:
        x = ser.read(500)
        if x:
            if start_time is None:
                start_time = time.time()
            last_data_time = time.time()
            raw_bytes.extend(x)
            binary_file.write(x)
        if time.time() - last_data_time > IDLE_TIMEOUT:
            break

    binary_file.close()

    # Unpack 2 bytes per sample into 12-bit values
    samples = []
    txt_file = open("raw_ADC_values.txt", "w")
    i = 0
    data = bytes(raw_bytes)
    while i + 1 < len(data):
        high = data[i]
        low  = data[i + 1]
        sample = (high << 8) | low   # reconstruct 12-bit value
        samples.append(sample)
        txt_file.write(f"{sample}\n")
        i += 2
    txt_file.close()

    if start_time is not None:
        elapsed = last_data_time - start_time
        actual_rate = len(samples) / elapsed
        print(f"Samples received: {len(samples)}")
        print(f"Elapsed time: {elapsed:.2f} seconds")
        print(f"Actual sample rate: {actual_rate:.0f} sps")

    return samples

# def save_files(ser):
#     samples = []
#     binary_file = open("raw_ADC_values.data", "wb")
#     txt_file = open("raw_ADC_values.txt", "w")

#     last_data_time = time.time()
#     start_time = None  # ADD THIS

#     while True:
#         x = ser.read(500)

#         if x:
#             if start_time is None:  # ADD THIS
#                 start_time = time.time()  # ADD THIS
#             last_data_time = time.time()
#             binary_file.write(x)
#             for byte in x:              # each byte is one complete sample
#                 samples.append(byte)
#                 txt_file.write(f"{byte}\n")

#         if time.time() - last_data_time > IDLE_TIMEOUT:
#             break

#     txt_file.close()
#     binary_file.close()

#     #debug samples printing
#     if start_time is not None:
#         elapsed = last_data_time - start_time
#         actual_rate = len(samples) / elapsed
#         print(f"Samples received: {len(samples)}")
#         print(f"Elapsed time: {elapsed:.2f} seconds")
#         print(f"Actual sample rate: {actual_rate:.0f} sps")
#     return samples
#----------------------------------------------------------------------------------------------------------------#
#added functions for task2
def menu():
    print("\n=== AUDIO SYSTEM ===")
    print("1. Manual Mode")
    print("2. Distance Mode")
    print("0. Exit")
    return input("Select: ")

def output_menu():
    print("\n=== OUTPUT SELECTION MENU ===")
    print("1. WAV only")
    print("2. CSV only")
    print("3. PNG only")
    print("4. ALL (WAV + CSV + PNG)")
    choice = input("Select option (1-4): ")
    return choice

def send_mode(ser, mode):
    if mode == "1":
        ser.write(b'M')
    elif mode == "2":
        ser.write(b'D')
    elif mode == "0":
        ser.write(b'S')

def manual_mode(ser,output):
    duration = float(input("Enter duration (seconds): "))
    send_mode(ser,"1")
    time.sleep(0.05)
    ser.reset_input_buffer()
    ser.write(struct.pack('f', duration))

    samples = save_files(ser)
    if output==1:
        generate_wav()
    elif output==2:
        save_csv(samples)
    elif output==3:
        plot_wave(samples)
    elif output==4:
        generate_wav()
        save_csv(samples)
        plot_wave(samples)
    send_mode(ser,"0")

def distance_mode(ser, output):
    send_mode(ser, "2")
    time.sleep(0.05) 
    ser.reset_input_buffer()

    while True:
        print("Waiting for proximity trigger...")
        samples = save_files(ser)
        if samples:  # only generate output if data was actually received
            if output == 1:
                generate_wav()
            elif output == 2:
                save_csv(samples)
            elif output == 3:
                plot_wave(samples)
            elif output == 4:
                generate_wav()
                save_csv(samples)
                plot_wave(samples)
        cont = input("Continue in distance mode? (y/n): ")
        if cont.lower() != 'y':
            break
    send_mode(ser, "0")

def save_csv(samples):
    csv_name = f"{TEAM_ID}_{SAMPLE_RATE}Hz_audio.csv"
    with open(csv_name, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([f"Sample Rate: {SAMPLE_RATE} Hz"])  # first row = sample rate
        writer.writerow(["Sample Index", "ADC Value"])
        for i, s in enumerate(samples):
            writer.writerow([i, s])
    print(f"CSV saved: {csv_name}")

def plot_wave(samples):
    time_axis = [i / SAMPLE_RATE for i in range(len(samples))]
    plt.figure(figsize=(10, 4))
    plt.plot(time_axis, samples, linewidth=0.5)
    plt.title("Recorded Audio - Amplitude vs Time")
    plt.xlabel("Time (seconds)")
    plt.ylabel("ADC Amplitude (0-255))")#4095
    plt.tight_layout()
    png_name = f"{TEAM_ID}_{SAMPLE_RATE}Hz_waveform.png"
    plt.savefig(png_name, dpi=150)
    plt.close()
    print(f"Plot saved: {png_name}")

def main():
    # ser = connect_serial()
    # print("Sending test byte...")
    # ser.write(b'X')
    # time.sleep(1)
    # print("Done")
    # ser.close()

    ser = connect_serial()
    mode = int(menu())
    output = int(output_menu())
    while True:
        if mode==1:
            manual_mode(ser,output)
        elif mode==2:
            distance_mode(ser,output)
        mode = int(menu())
        if (mode==0):
            break;
        output = int(output_menu())
    ser.close()
    

if __name__=="__main__":
    main()
