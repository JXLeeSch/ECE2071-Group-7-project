import serial
import time

ser = serial.Serial(port="COM5", baudrate=921600, bytesize=8, parity="N", stopbits=1, timeout=0.1)
print("Listening...")

start = time.time()
count = 0
while time.time() - start < 8:
    x = ser.read(500)
    if x:
        count += len(x)
        print(f"Received {count} bytes so far")

ser.close()
print(f"Total: {count} bytes")