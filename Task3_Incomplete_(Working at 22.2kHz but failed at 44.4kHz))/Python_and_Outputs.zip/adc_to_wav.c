#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define CHANNELS 1
#define BITS_PER_SAMPLE 8

void write_le16(FILE *file, uint16_t value)
{
    fputc(value & 0xFF, file);
    fputc((value >> 8) & 0xFF, file);
}

void write_le32(FILE *file, uint32_t value)
{
    fputc(value & 0xFF, file);
    fputc((value >> 8) & 0xFF, file);
    fputc((value >> 16) & 0xFF, file);
    fputc((value >> 24) & 0xFF, file);
}

int main(int argc, char *argv[])
{
    printf("Program started\n");

    if (argc != 4)
    {
        printf("Usage: wav_converter_test <input.data> <output.wav> <sample_rate>\n");
        return 1;
    }

    const char *input_filename = argv[1];
    const char *output_filename = argv[2];
    uint32_t sample_rate = (uint32_t)atoi(argv[3]);

    printf("Input: %s\n", input_filename);
    printf("Output: %s\n", output_filename);
    printf("Sample rate: %u\n", sample_rate);

    FILE *input = fopen(input_filename, "rb");
    if (input == NULL)
    {
        printf("Error opening input file.\n");
        return 1;
    }

    FILE *output = fopen(output_filename, "wb");
    if (output == NULL)
    {
        printf("Error opening output file.\n");
        fclose(input);
        return 1;
    }

    printf("Files opened\n");

    fseek(input, 0, SEEK_END);
    long input_size_long = ftell(input);
    rewind(input);

    if (input_size_long <= 0)
    {
        printf("Input file is empty.\n");
        fclose(input);
        fclose(output);
        return 1;
    }

    uint32_t input_size = (uint32_t)input_size_long;

    /*
     * Task 3:
     * Processing STM sends 8-bit samples.
     * Therefore:
     * 1 input byte = 1 audio sample
     */
    uint32_t num_samples = input_size;
    uint32_t data_chunk_size = num_samples;
    uint32_t riff_chunk_size = 36 + data_chunk_size;

    uint32_t byte_rate = sample_rate * CHANNELS * BITS_PER_SAMPLE / 8;
    uint16_t block_align = CHANNELS * BITS_PER_SAMPLE / 8;

    printf("Input size: %u bytes\n", input_size);
    printf("Samples: %u\n", num_samples);

    /*
     * WAV header
     */
    fwrite("RIFF", 1, 4, output);
    write_le32(output, riff_chunk_size);
    fwrite("WAVE", 1, 4, output);

    fwrite("fmt ", 1, 4, output);
    write_le32(output, 16);              // PCM format chunk size
    write_le16(output, 1);               // Audio format = PCM
    write_le16(output, CHANNELS);        // Mono
    write_le32(output, sample_rate);
    write_le32(output, byte_rate);
    write_le16(output, block_align);
    write_le16(output, BITS_PER_SAMPLE);

    fwrite("data", 1, 4, output);
    write_le32(output, data_chunk_size);

    printf("Header written\n");

    /*
     * For unsigned 8-bit PCM WAV:
     * 0   = minimum
     * 128 = centre
     * 255 = maximum
     *
     * Your Processing STM already sends unsigned 8-bit samples,
     * so we can copy bytes directly.
     */
    int c;
    while ((c = fgetc(input)) != EOF)
    {
        fputc((uint8_t)c, output);
    }

    printf("Samples converted\n");

    fclose(input);
    fclose(output);

    printf("Done\n");
    return 0;
}