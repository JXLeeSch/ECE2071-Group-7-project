#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// #define INPUT_FILE "raw_ADC_values.data" // name of input file containing adc values
// #define OUTPUT_FILE "Team07_6400Hz_output.wav" //name of output file to write to

// #define SAMPLE_RATE 6400 //given audio sampling frequency
#define BITS_PER_SAMPLE 16 //wav uses 16 bits per sample 
#define CHANNELS 1 //we are only using a single channel 
#define ADC_MAX 4095 //maximum value of ADC data 

//function prototypes for converting into little endian format
void little_endian_16(FILE *file, uint16_t value);
void little_endian_32(FILE *file, uint32_t value);

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: adc_to_wav <input_file> <output_file> <sample_rate>\n");
        return 1;
    }

    const char *input_file  = argv[1];
    const char *output_file = argv[2];
    uint32_t sample_rate    = (uint32_t)atoi(argv[3]);

    FILE *input  = fopen(input_file, "rb");
    FILE *output = fopen(output_file, "wb");

    if(!input || !output) //checking for errors in opening files
    {
        printf("Error opening file.");
        return 1;
    }

    fseek(input,0,SEEK_END); //first we move the input pointer to the end of the input file
    uint32_t input_size = ftell(input); //ftell tells us the position of the last byte of the input file, which is also the size of the input file
    rewind(input); //move input pointer back to the start so we can use it later 

    uint32_t num_samples = input_size/2; //each ADC sample is 2 bytes, giving us the total number of samples
    uint32_t data_chunk_size = num_samples*2; //each output wav sample is also 2 bytes
    uint32_t file_size = 36 + data_chunk_size; //wav header is 44 bytes, and output file size is calculated previously, giving us total file size

    //first we write wav header, then convert adc samples into pcm
    fwrite("RIFF", 1, 4, output);
    little_endian_32(output, file_size);
    fwrite("WAVE", 1, 4, output);

    fwrite("fmt ", 1, 4, output);
    little_endian_32(output, 16);
    little_endian_16(output, 1);
    little_endian_16(output, CHANNELS);
    little_endian_32(output, sample_rate);
    uint32_t byte_rate = sample_rate * CHANNELS * BITS_PER_SAMPLE / 8;
    little_endian_32(output, byte_rate);
    uint16_t block_align = CHANNELS * BITS_PER_SAMPLE / 8;
    little_endian_16(output, block_align);
    little_endian_16(output, BITS_PER_SAMPLE);

    fwrite("data", 1, 4, output);
    little_endian_32(output, data_chunk_size);

    //now we begin converting adc samples
    uint8_t buffer[2];//temporary storage for 2 byte adc sample
    while (fread(buffer, 1, 2, input) == 2)//reading adc samples until file ends
    {
        uint16_t adc_value = buffer[0] | (buffer[1] << 8); //reconstructing adc value from little endian value
        //the formula for converting adc to pcm is: (adc * 65535 / 4095) - 32768
        int16_t pcm_value = (int16_t)(((int32_t)adc_value * 65535 / ADC_MAX) - 32768); 
        little_endian_16(output, pcm_value);
    }
    //closing files
    fclose(input);
    fclose(output);

    return 0;
}

void little_endian_16(FILE *file, uint16_t value) //function to write 16 bits in little endian format
{
    fputc(value & 0XFF,file); //writing least significant byte first
    fputc((value >>8)& 0xFF,file); //writing most significant byte second
}

void little_endian_32(FILE *file, uint32_t value) //function to write 32 bits in little endian format
{
    fputc(value&0xFF,file); //writing least significant byte first
    fputc((value>>8)&0xFF,file);
    fputc((value>>16)&0xFF,file);
    fputc((value>>24)&0xFF,file); //writing most significant byte last
}