import serial
import struct
import subprocess
import time
import matplotlib.pyplot as plt
import csv
import os

SAMPLE_RATE = 6400
COM_PORT = "COM5"
BAUD_RATE = 230400
TEAM_ID = "Team07"

IDLE_TIMEOUT = 1
 
def connect_serial():
    ser = serial.Serial(port=COM_PORT,baudrate=BAUD_RATE,bytesize=8,parity="N",stopbits=1,timeout=0.1)
    print(ser.name)
    return ser

def generate_wav():
    compile_result = subprocess.run(["gcc", "adc_to_wav.c", "-o", "adc_to_wav"],capture_output=True,text=True)

    if compile_result.returncode != 0:
        print("Compilation failed:")
        print(compile_result.stderr)
        return
    else:
        print("Compilation successful.")

    output_filename = f"{TEAM_ID}_{SAMPLE_RATE}Hz_output.wav"
    run_result = subprocess.run(
        ["adc_to_wav.exe", "raw_ADC_values.data", output_filename, str(SAMPLE_RATE)],
        capture_output=True, text=True
    )#use ["./adc_to_wav"] for linux, ["adc_to_wav.exe"] for windows

    if run_result.returncode != 0:
        print("C program failed:")
        print(run_result.stderr)
    else:
        print(f"WAV file generated: {output_filename}")

def save_files(ser):
    samples = []
    binary_file = open("raw_ADC_values.data", "wb")
    txt_file = open("raw_ADC_values.txt", "w")

    buffer = bytearray()
    last_data_time = time.time()

    while True:
        x = ser.read(500)

        if x:
            last_data_time = time.time()
            binary_file.write(x)
            buffer.extend(x)

            while len(buffer) >= 2:
                adc_value = buffer[0] | (buffer[1] << 8)
                samples.append(adc_value)
                txt_file.write(f"{adc_value}\n")
                del buffer[0:2]

        if time.time() - last_data_time > IDLE_TIMEOUT:
            break

    txt_file.close()
    binary_file.close()
    return samples
#----------------------------------------------------------------------------------------------------------------#
#added functions for task2
def menu():
    print("\n=== AUDIO SYSTEM ===")
    print("1. Manual Mode")
    print("2. Distance Mode")
    print("0. Exit")
    return input("Select: ")

def output_menu():
    print("\n=== OUTPUT SELECTION MENU ===")
    print("1. WAV only")
    print("2. CSV only")
    print("3. PNG only")
    print("4. ALL (WAV + CSV + PNG)")
    choice = input("Select option (1-4): ")
    return choice

def send_mode(ser, mode):
    if mode == "1":
        ser.write(b'M')
    elif mode == "2":
        ser.write(b'D')
    elif mode == "0":
        ser.write(b'S')

def manual_mode(ser,output):
    duration = float(input("Enter duration (seconds): "))
    send_mode(ser,"1")
    time.sleep(0.05)
    ser.reset_input_buffer()

    ser.write(struct.pack('f', duration))

    samples = save_files(ser)
    if output==1:
        generate_wav()
    elif output==2:
        save_csv(samples)
    elif output==3:
        plot_wave(samples)
    elif output==4:
        generate_wav()
        save_csv(samples)
        plot_wave(samples)
    send_mode(ser,"0")

def distance_mode(ser, output):
    send_mode(ser, "2")
    time.sleep(0.05) 
    ser.reset_input_buffer()

    while True:
        print("Waiting for proximity trigger...")
        samples = save_files(ser)
        if samples:  # only generate output if data was actually received
            if output == 1:
                generate_wav()
            elif output == 2:
                save_csv(samples)
            elif output == 3:
                plot_wave(samples)
            elif output == 4:
                generate_wav()
                save_csv(samples)
                plot_wave(samples)
        cont = input("Continue in distance mode? (y/n): ")
        if cont.lower() != 'y':
            break
    send_mode(ser, "0")

def save_csv(samples):
    csv_name = f"{TEAM_ID}_{SAMPLE_RATE}Hz_audio.csv"
    with open(csv_name, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([f"Sample Rate: {SAMPLE_RATE} Hz"])  # first row = sample rate
        writer.writerow(["Sample Index", "ADC Value"])
        for i, s in enumerate(samples):
            writer.writerow([i, s])
    print(f"CSV saved: {csv_name}")

def plot_wave(samples):
    time_axis = [i / SAMPLE_RATE for i in range(len(samples))]
    plt.figure(figsize=(10, 4))
    plt.plot(time_axis, samples, linewidth=0.5)
    plt.title("Recorded Audio - Amplitude vs Time")
    plt.xlabel("Time (seconds)")
    plt.ylabel("ADC Amplitude (0-4095)")
    plt.tight_layout()
    png_name = f"{TEAM_ID}_{SAMPLE_RATE}Hz_waveform.png"
    plt.savefig(png_name, dpi=150)
    plt.close()
    print(f"Plot saved: {png_name}")

def main():
    ser = connect_serial()
    mode = int(menu())
    output = int(output_menu())
    while True:
        if mode==1:
            manual_mode(ser,output)
        elif mode==2:
            distance_mode(ser,output)
        mode = int(menu())
        if (mode==0):
            break;
        output = int(output_menu())
    ser.close()
    

if __name__=="__main__":
    main()
